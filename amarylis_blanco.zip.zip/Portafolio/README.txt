Coloca una imagen llamada 'perfil.jpg' dentro de la carpeta img para que se muestre en la sección Acerca de mí.
